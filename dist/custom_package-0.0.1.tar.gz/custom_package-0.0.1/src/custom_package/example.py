from custom_package.Fib import fib

def getFib(number):
    fib.fib(number)
# getFib(2000)
# print("Shehab")

